from distutils.core import setup

setup(
	name = 'sortUtil',
	version = '1.0.0',
	py_modules = ['sortArr'],
	author = 'xiongyangchao',
)
